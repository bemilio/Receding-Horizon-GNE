load 15_minute_data_new_york.mat
close all
T = minutedatanewyork;
T.local_15min = string(T.local_15min);
T.local_15min = datetime(T.local_15min, 'InputFormat', 'yyyy-MM-dd HH:mm:ssXXX', 'TimeZone', 'local');

% Get unique user IDs
userIDs = unique(T.dataid);

% Initialize a cell array to store the results
numUsers = 10;
userDataCell = {};


% Loop through each user ID and process the data
for i = 1:numUsers
    % Extract the data for the current user
    userData = T(T.dataid==userIDs(i), :);
     % Check if all data is positive
    % Sort the user data by timestamp
    userData = sortrows(userData, 'local_15min');
    
    % Store the relevant numerical data in a field named after the user ID
    userDataCell{i} = userData.grid;
    userTimestampCell{i} = userData.local_15min;
end

minLength = min(cellfun(@length, userDataCell));
% Cut the data for each user to match the minimum length
for i = 1:numUsers
    userDataCell{i} = userDataCell{i}(1:minLength);
    userTimestampCell{i} = userTimestampCell{i}(1:minLength);
end


% Combine the data from all users
combinedData = [];
combinedTimestamp = [];

for i = 1:numUsers
    combinedData = [combinedData; userDataCell{i}];
    combinedTimestamp = [combinedTimestamp; userTimestampCell{i}];
end

% Create a table with combined data and timestamps
combinedTable = table(combinedTimestamp, combinedData, 'VariableNames', {'Timestamp', 'Data'});

% Group by timestamp and sum the data
groupedData = varfun(@sum, combinedTable, 'InputVariables', 'Data', 'GroupingVariables', 'Timestamp');

% Filter data for the first two days
startDateTime = min(combinedTimestamp);
endDateTime = startDateTime + days(2);
filteredData = groupedData(groupedData.Timestamp >= startDateTime & groupedData.Timestamp <= endDateTime, :);

% Plot the filtered data
figure;
plot(filteredData.Timestamp, -filteredData.sum_Data, '-o');
xlabel('Timestamp');
ylabel('Aggregate Power');
grid on